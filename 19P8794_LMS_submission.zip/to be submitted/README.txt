README

1) Download the requirements.txt file in your python environment.

2) Kaggle dataset is in the same root directory as the ipynb notebook.